from furbain import config

# Create the config file if it doesn't exist
config.createConfigurationFile()